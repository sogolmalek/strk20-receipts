# Wallet proof: Payproof receipts without a 15 GB prover

**A STRK20 payment receipt was proven by a hosted SNIP-36 prover, the same kind of service STRK20 wallets already use for every pool transaction, and accepted on Starknet Sepolia.** No local prover, no special hardware: building the transaction and getting the proof took 4 seconds.

This answers the obvious question about Payproof: *can a normal wallet user, on a phone or a laptop, actually make a receipt?* Yes. A wallet sends the receipt's virtual transaction to its own prover, exactly as it already does for deposits and transfers.

## The evidence

Both runs below use the same contracts, account and flow. The only difference is who produced the proof.

| | Local prover | Hosted prover (wallet-style) |
| --- | --- | --- |
| Prover | snip36 prebuilt prover on the CI machine | StarkWare's Sepolia transaction prover |
| Time to proof | 93 s of proving | 4 s, including building the transaction |
| Memory needed on our side | 14.3 GB peak | none (only the `snip36` CLI) |
| Receipt registered | [0x44a1bd82…6368](https://sepolia.voyager.online/tx/0x44a1bd825776295203735a4f2ea702200836d3899047cd9fe5eac30c2726368), block 16,964,292 | [0x3bd7aa55…bfde](https://sepolia.voyager.online/tx/0x3bd7aa557b17cac51e8277735176ec68bcc62d73e19dc5494bdddd0c3c2bfde), block 16,964,625 |
| Verified from the opening alone | yes | yes |
| Tampered opening rejected | yes | yes |
| CI run | [#2](https://github.com/sogolmalek/strk20-receipts/actions/runs/39726185996) | [#3](https://github.com/sogolmalek/strk20-receipts/actions/runs/39727236033) |

What we checked on chain for the hosted-prover receipt:

- The transaction succeeded and carries SNIP-36 proof facts.
- The proof facts name program hash `0x53f6c9fcfd31d27279ff7d7e422b44623550a732b59fe193354a7316a96daa1`, the official virtual OS that the [SNIP-36 prover backend](https://github.com/starknet-innovation/snip-36-prover-backend) publishes.
- The message hash in the proof facts, `0xf54a921df14986eb3eefea7b2ac150417485f73d6f8859de1a07398ec02ec9`, equals the hash we recompute from the receipt contract's class hash and this receipt's commitment. The proof is about this receipt and nothing else.
- Base block 16,964,605; registered 20 blocks later, inside the contract's validity window.

## What a wallet flow looks like

```mermaid
sequenceDiagram
    participant U as User
    participant W as Wallet (Ready, Xverse, ...)
    participant P as Wallet's SNIP-36 prover
    participant S as Starknet
    participant V as Verifier (landlord, accountant, ...)
    U->>W: "Prove this payment: at least 3,000 USDC, ref PAYROLL-2026-09"
    W->>W: build prove_payment virtual tx, sign it (zero fee)
    W->>P: starknet_proveTransaction (same call as for pool transactions)
    P-->>W: proof + proof facts (seconds)
    W->>S: register_receipt(commitment) with the proof, via a paymaster
    W-->>U: receipt link (opening, no key)
    U->>V: share the link
    V->>S: storage proof of registered[commitment]
    V->>V: recompute the commitment: VERIFIED
```

For a wallet this is one more call to infrastructure it already runs. The receipt contract, SDK and verify page do the rest.

## Who sees what

| Proving mode | Time | Who sees the inputs (channel key) | Best for |
| --- | --- | --- | --- |
| Wallet's own prover | seconds | The wallet's prover, which already proves this user's pool transactions | Everyday users |
| Payer's prover (e.g. a payroll app) | seconds | The payer, who shares the channel key and already knows the payment | Proof of income, payslips |
| Local prover | ~1.5 min, ~14 GB RAM | Nobody | Zero-trust users, businesses |

A receipt therefore adds no new trust assumption for wallet users: it goes to the same prover that already handles their private transactions. The one rule: **never send a real channel key to a prover you do not already trust with your pool transactions.** The run above is safe on a public prover because path B proves StarkWare's public reference note (channel key `0xdef`), not a real payment.

## Reproduce it

**In CI (no setup):** Actions → *Sepolia receipt (path B, real SNIP-36 proof)* → Run workflow, and set `prover_url` to `https://transaction-prover.alpha-sepolia.sw-dev.io`. Or run *Sepolia receipt (hosted prover, wallet-style)*, which has that preset and skips installing the local prover.

**On your machine:** with a Sepolia `.env` as in [RUNBOOK-SEPOLIA.md](../RUNBOOK-SEPOLIA.md) (path B) and the `snip36` CLI installed (no prover stack needed):

```bash
./wallet-proof/prove-with-hosted-prover.sh
```

## Integration sketch for wallet teams

```ts
import { executeCalldata, provePaymentCalldata, referenceFelt } from "strk20-receipts/client/src/receipt";

// 1. The receipt's virtual transaction: a zero-fee INVOKE v3 calling prove_payment.
const calldata = executeCalldata(RECEIPT_CONTRACT, "prove_payment",
  provePaymentCalldata(note, { kind: "atLeast", value: 3_000_000_000n }, referenceFelt("PAYROLL-2026-09"), blinding));
// Sign it with the wallet's normal signer at the base block's nonce (see virtualTxJson / invokeV3Hash).

// 2. Prove it with the wallet's existing SNIP-36 prover.
const { result } = await fetch(WALLET_PROVER_URL, {
  method: "POST", headers: { "content-type": "application/json" },
  body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "starknet_proveTransaction",
    params: { block_id: { block_number: baseBlock }, transaction: signedVirtualTx } }),
}).then((r) => r.json());

// 3. Register the commitment with the proof attached (ideally through a paymaster).
await account.execute(
  [{ contractAddress: RECEIPT_CONTRACT, entrypoint: "register_receipt", calldata: [commitment] }],
  { proofFacts: result.proof_facts, proof: result.proof },
);
// 4. Give the user the opening: anyone can verify it with no key and no wallet.
```

The SDK planned for milestone 1 wraps these steps into `prove`, `register` and `verify`.
