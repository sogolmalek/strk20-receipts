#!/usr/bin/env bash
# Wallet-style receipt: prove with a hosted SNIP-36 prover instead of the local 15 GB prover.
#
# Uses path B (StarkWare's public reference note in the Sepolia MockPool), so the prover input
# holds no secret. Never send a real channel key to a prover you do not already trust with your
# pool transactions.
#
# Needs: the snip36 CLI (no prover stack), Node >= 24, and a Sepolia .env as in RUNBOOK-SEPOLIA.md
# path B (STARKNET_CHAIN_ID=SN_SEPOLIA, account, POOL=<MockPool>, RECEIPT_CONTRACT).
set -euo pipefail

PROVER_URL="${PROVER_URL:-https://transaction-prover.alpha-sepolia.sw-dev.io}"
RPC_URL="${STARKNET_RPC_URL:-https://starknet-sepolia-rpc.publicnode.com}"
REFERENCE="${REFERENCE:-INV-WALLET-LOCAL}"

cd "$(dirname "$0")/../client"
npx tsx scripts/00-mock-note.ts
npx tsx scripts/03-make-virtual-tx.ts --note private-note.json --claim atLeast:900 --reference "$REFERENCE"
BASE=$(node -e 'console.log(require("./out/meta.json").base_block)')

echo "Proving with $PROVER_URL"
time snip36 prove virtual-os --block-number "$BASE" --tx-json out/receipt_tx.json \
  --rpc-url "$RPC_URL" --prover-url "$PROVER_URL" --output out/receipt.proof

npx tsx scripts/04-register-receipt.ts --send
npx tsx scripts/05-verify.ts --opening out/opening.json --rpc "$RPC_URL"
